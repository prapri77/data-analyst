from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
import json
from .models import Bus, Flight, Train, Booking
from rest_framework.views import APIView
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.shortcuts import render, redirect, get_object_or_404
from .forms import FlightForm, BusForm, TrainForm, BookingForm
from django.contrib import messages
from datetime import date
from booking.serializers import (
    BookingSerializer,
    BusSerializer,
    TrainSerializer,
    FlightSerializer,
)
from rest_framework.viewsets import ModelViewSet
from rest_framework.decorators import action


@csrf_exempt
def busdetail(request):
    if request.method == "POST":
        payload = json.loads(request.body)

        # creating bus record using the passed json payload
        instance = Bus.objects.create(
            bus_number=payload.get("bus_number"),
            name=payload.get("name"),
            bus_type=payload.get("bus_type"),
            seat_type=payload.get("seat_type"),
            source=payload.get("source"),
            distination=payload.get("distination"),
            arrival_time=payload.get("arrival_time"),
            departure_time=payload.get("departure_time"),
            price=payload.get("price"),
        )

        return JsonResponse(
            {
                "message": "record created",
                "details": {
                    "id": instance.id,
                    "name": instance.name,
                    "veh_no": instance.bus_number,
                },
            }
        )
    elif request.method == "GET":
        records = Bus.objects.all()
        buses_list = []
        for record in records:
            buses_list.append(
                {
                    "vehicle_number": record.bus_number,
                    "travels_name": record.name,
                    "boardingpoint": record.source,
                    "destined_location": record.distination,
                    "boarding_time": record.arrival_time,
                }
            )

        return JsonResponse(buses_list, safe=False)


@csrf_exempt
def bus_ud(request, id):
    """
    this function received the record id to update or deleted the record
    """
    if request.method == "PUT":
        payload = json.loads(request.body)
        # filtering the specific record
        # instance = Bus.objects.filter()
        instance = Bus.objects.get(id=id)

        instance.bus_number = payload.get("veh_no", instance.bus_number)
        instance.name = payload.get("name", instance.name)
        instance.bus_type = payload.get("bus_type", instance.bus_type)
        instance.seat_type = payload.get("seat_type", instance.seat_type)
        instance.source = (payload.get("source", instance.source),)
        instance.distination = payload.get("distination", instance.distination)
        instance.arrival_time = payload.get("arrival_time", str(instance.arrival_time))

        instance.departure_time = payload.get(
            "departure_time", str(instance.departure_time)
        )
        instance.price = payload.get("price", instance.price)
        instance.save()

        return JsonResponse(
            {
                "message": "record updated",
                "details": {
                    "id": instance.id,
                    "name": instance.name,
                    "veh_no": instance.bus_number,
                },
            }
        )
    elif request.method == "DELETE":
        instance = Bus.objects.get(id=id)
        instance.delete()
        return JsonResponse({"message": "record delete"})


class TrainCrud(APIView):
    def get(self, request):
        data = Train.objects.all().values()
        return Response(data)

    def post(self, request):
        payload = request.data
        Train.objects.create(
            engine_number=payload.get("engine_number"),
            name=payload.get("name"),
            train_type=payload.get("train_type"),
            seat_type=payload.get("seat_type"),
            source=payload.get("source"),
            distination=payload.get("distination"),
            arrival_time=payload.get("arrival_time"),
            departure_time=payload.get("departure_time"),
            price=payload.get("price"),
        )
        return Response("Train record created successfully")


@api_view(["PUT", "DELETE"])
def Train_ud(request, id):
    if request.method == "PUT":
        payload = request.data
        instance = Train.objects.get(id=id)
        instance.engine_number = payload.get("engine_number", instance.engine_number)
        instance.name = payload.get("name", instance.name)
        instance.train_type = payload.get("train_type", instance.train_type)
        instance.seat_type = payload.get("seat_type", instance.seat_type)
        instance.source = payload.get("source", instance.source)
        instance.distination = payload.get("distination", instance.distination)
        instance.arrival_time = payload.get("arrival_time", instance.arrival_time)
        instance.departure_time = payload.get("departure_time", instance.departure_time)
        instance.price = payload.get("price", instance.price)
        instance.save()

        return Response("record updated")
    elif request.method == "DELETE":
        instance = Train.objects.get(id=id)
        instance.delete()
        return Response("record deleted")


@api_view(["GET", "POST"])
def bulk_create_bus(request):
    if request.method == "POST":

        data = request.data

        # bulk create will save time
        Buses = [
            Bus(
                bus_number=payload.get("bus_number"),
                name=payload.get("name"),
                bus_type=payload.get("bus_type"),
                seat_type=payload.get("seat_type"),
                source=payload.get("source"),
                distination=payload.get("distination"),
                arrival_time=payload.get("arrival_time"),
                departure_time=payload.get("departure_time"),
                price=payload.get("price"),
            )
            for payload in data
        ]

        Bus.objects.bulk_create(Buses)
        return Response("Bulk creation of bussess successfuly")
    else:
        return Response("pass massive data to process and store in db")


@api_view(["GET", "POST"])
def bulk_create_trains(request):
    if request.method == "POST":

        data = request.data

        # bulk create will save time
        Trains = [
            Train(
                engine_number=payload.get("engine_number"),
                name=payload.get("name"),
                train_type=payload.get("train_type"),
                seat_type=payload.get("seat_type"),
                source=payload.get("source"),
                distination=payload.get("distination"),
                arrival_time=payload.get("arrival_time"),
                departure_time=payload.get("departure_time"),
                price=payload.get("price"),
            )
            for payload in data
        ]

        Train.objects.bulk_create(Trains)
        return Response("Bulk creation of trains successfuly")
    else:
        return Response("pass massive data to process and store in db")


def flight_html(request):
    if request.method == "POST":
        # validating the HTML data
        form = FlightForm(request.POST)
        print("received form ", form)
        if form.is_valid():
            form.save()
            return HttpResponse("Flight Data processed successfully")
    else:
        flights = Flight.objects.all().order_by("-departure_time")
        form = FlightForm()
        context = {"form": form, "flights": flights}

    return render(request, "flights_data.html", context)


def bus_html(request):
    """
    Handles GET and POST requests to list buses and create new bus records.
    """
    form = BusForm(request.POST or None)

    if request.method == "POST":
        if form.is_valid():
            form.save()
            messages.success(request, "✅ Bus record created successfully.")
            return redirect("bus_html")  # replace with your URL name
        else:
            messages.error(request, "❌ Invalid bus data submitted.")

    bus_data = Bus.objects.all().order_by("-id")
    return render(request, "bus.html", {"form": form, "busses": bus_data})


def train_html(request):
    """
    Handles GET and POST requests to list buses and create new bus records.
    """
    form = TrainForm(request.POST or None)

    if request.method == "POST":
        if form.is_valid():
            form.save()
            messages.success(request, "✅ Bus record created successfully.")
            return redirect("train_html")  # replace with your URL name
        else:
            messages.error(request, "❌ Invalid Train data submitted.")

    train_data = Train.objects.all().order_by("-id")
    return render(request, "train.html", {"form": form, "trains": train_data})


def select_bus(request, id):
    data = get_object_or_404(Bus, id=id)
    print("bus_data ", data)
    return render(
        request,
        "selected_bus.html",
        {"bus": data, "booking_details": str(data.id) + ", bus"},
    )


def select_train(request, id):
    train = get_object_or_404(Train, id=id)
    return render(
        request,
        "selected_train.html",
        {"train": train, "booking_details": str(train.id) + ", train"},
    )


def booking_view(request):
    """
    this method must handle three cases initially from the selected_bus or selected_train html
    we can use post part otherwise we need to send the booking.html to receive data

    """
    if request.method == "POST":
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.user = request.user
            booking.status = "confirmed"
            form.save()
            messages.success(request, "booking created")

        else:
            messages.success(request, "invalid datas you passed")

    form = BookingForm()
    # taking the user detaisl and returning all the bookings existing
    existing_bookings = Booking.objects.filter(user=request.user.id).order_by(
        "-booking_date"
    )
    return render(
        request,
        "booking.html",
        {"form": form, "existing_bookings": existing_bookings},
    )


def booking_html_data(request, data):
    print("booking from data htmls ", data)
    record_id, type = data.strip().lower().split(",")

    instance = None
    vehicle = None

    if type.strip() == "bus":
        vehicle = get_object_or_404(Bus, id=int(record_id))
        instance = Booking.objects.create(
            user=request.user,
            transport_type="Bus",
            transport_id=vehicle.id,
            travel_date=(
                vehicle.arrival_time.date() if vehicle.arrival_time else date.today()
            ),
        )

    elif type.strip() == "train":
        vehicle = get_object_or_404(Train, id=int(record_id))
        instance = Booking.objects.create(
            user=request.user,
            transport_type="Train",
            transport_id=vehicle.id,
            travel_date=(
                vehicle.arrival_time.date() if vehicle.arrival_time else date.today()
            ),
        )

    elif type.strip() == "flight":
        vehicle = get_object_or_404(Flight, id=int(record_id))
        instance = Booking.objects.create(
            user=request.user,
            transport_type="Flight",
            transport_id=vehicle.id,
            travel_date=(
                vehicle.arrival_time.date() if vehicle.arrival_time else date.today()
            ),
        )

    return render(
        request, "booking_confirmed.html", {"vehicle": vehicle, "booking": instance}
    )


class BookingViewSet(ModelViewSet):
    """
    A viewset for viewing and editing Booking instances.
    """

    queryset = Booking.objects.all()
    serializer_class = BookingSerializer

    @action(url_name="my_bookings", detail=False, methods=["get"])
    def my_bookings(self, request):
        """
        the classification of the bookings based the types of transportation
        and the user who made the booking.
        """
        user = request.user
        bookings = Booking.objects.filter(user=user).order_by("-booking_date")
        serializer = self.get_serializer(bookings, many=True)
        # classifying bus, train and flight bookings
        bus_bookings = [b for b in serializer.data if b["transport_type"] == "Bus"]
        train_bookings = [b for b in serializer.data if b["transport_type"] == "Train"]
        flight_bookings = [
            b for b in serializer.data if b["transport_type"] == "Flight"
        ]
        return Response(
            {
                "bus_bookings": bus_bookings,
                "train_bookings": train_bookings,
                "flight_bookings": flight_bookings,
            }
        )


class BusViewSet(ModelViewSet):
    """
    A viewset for viewing and editing Bus instances.
    """

    queryset = Bus.objects.all()
    serializer_class = BusSerializer

    def get_queryset(self):
        return self.queryset.order_by("-id")  # Order by ID in descending order

    @action(url_name="bus_classification", detail=False, methods=["get"])
    def bus_classification(self, request):
        """
        Classifies buses based on their types.
        """
        buses = self.get_queryset()
        bus_types = {"AC": [], "Non Ac": []}
        for bus in buses:
            serialized_bus = self.get_serializer(bus).data
            bus_types[bus.bus_type].append(serialized_bus)
        print("bus_types ", bus_types)
        return Response(bus_types)


class TrainViewSet(ModelViewSet):
    """
    A viewset for viewing and editing Train instances.
    """

    queryset = Train.objects.all()
    serializer_class = TrainSerializer

    def get_queryset(self):
        return self.queryset.order_by("-id")  # Order by ID in descending order

    @action(url_name="train_classification", detail=False, methods=["get"])
    def train_classification(self, request):
        """
        Classifies trains based on their types.
        """
        trains = self.get_queryset()
        train_types = {"AC": [], "Non Ac": []}
        for train in trains:
            serialized_train = self.get_serializer(train).data
            train_types[train.train_type].append(serialized_train)
        return Response(train_types)


class FlightViewSet(ModelViewSet):
    """
    A viewset for viewing and editing Flight instances.
    """

    queryset = Flight.objects.all()
    serializer_class = FlightSerializer

    def get_queryset(self):
        return self.queryset.order_by("-id")  # Order by ID in descending order
