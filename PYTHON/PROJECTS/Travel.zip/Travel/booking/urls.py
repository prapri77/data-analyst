from django.urls import path
from .views import (
    busdetail,
    bus_ud,
    TrainCrud,
    Train_ud,
    bulk_create_bus,
    bulk_create_trains,
    flight_html,
    bus_html,
    train_html,
    select_bus,
    select_train,
    booking_view,
    booking_html_data,
    BookingViewSet,
    BusViewSet,
    TrainViewSet,
    FlightViewSet,
)

app_name = "travel"
from rest_framework.routers import DefaultRouter
from django.urls import include

# Create a router and register the BookingViewSet with it
router = DefaultRouter()
router.register("bookview", BookingViewSet, basename="booking")
router.register("busview", BusViewSet, basename="bus")
router.register("trainview", TrainViewSet, basename="train")
router.register("flightview", FlightViewSet, basename="flight")

urlpatterns = [
    path("bus_api", busdetail),
    path("bus_ud/<int:id>", bus_ud),
    path("Train", TrainCrud.as_view()),
    path("Train_ud/<int:id>", Train_ud),
    path("bulk_create", bulk_create_trains),
    path("flights/", flight_html, name="flight_data_view"),
    path("bus/", bus_html, name="bus_html"),
    path("train/", train_html, name="train_html"),
    path("select_bus/<int:id>", select_bus, name="select_bus"),
    path("select_train/<int:id>", select_train, name="select_train"),
    path("booking", booking_view, name="booking"),
    path("book_html/<str:data>", booking_html_data, name="book_html"),
    path("", include(router.urls)),
]
