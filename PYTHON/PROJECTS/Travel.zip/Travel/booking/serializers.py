from rest_framework.serializers import ModelSerializer, SerializerMethodField
from .models import Booking, Bus, Train, Flight


class BookingSerializer(ModelSerializer):
    travel_details = SerializerMethodField()

    def get_travel_details(self, obj):
        if obj.transport_type == "Bus":
            bus = Bus.objects.get(id=obj.transport_id)
            return {
                "name": bus.name,
                "source": bus.source,
                "destination": bus.distination,
                "departure_time": bus.departure_time,
                "arrival_time": bus.arrival_time,
                "price": bus.price,
            }
        elif obj.transport_type == "Train":
            train = Train.objects.get(id=obj.transport_id)
            return {
                "name": train.name,
                "source": train.source,
                "destination": train.distination,
                "departure_time": train.departure_time,
                "arrival_time": train.arrival_time,
                "price": train.price,
            }
        elif obj.transport_type == "Flight":
            try:
                flight = Flight.objects.get(id=obj.transport_id)
                return {
                    "airline": flight.airline,
                    "source": flight.source,
                    "destination": flight.distination,
                    "departure_time": flight.departure_time,
                    "arrival_time": flight.arrival_time,
                    "price": flight.price,
                }
            except Flight.DoesNotExist:
                return {"error": "Flight not found"}

    class Meta:
        model = Booking
        fields = "__all__"


class BusSerializer(ModelSerializer):
    class Meta:
        model = Bus
        fields = "__all__"


class TrainSerializer(ModelSerializer):
    class Meta:
        model = Train
        fields = "__all__"


class FlightSerializer(ModelSerializer):
    class Meta:
        model = Flight
        fields = "__all__"
